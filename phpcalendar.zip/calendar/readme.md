PHP Calendar V1.2                                 
copyright 2023 Steve Frazier                      
www.phpjunction.com                               
                                                   
You may modify and distribute this script free of  
charge as long as this readme.txt with the        
copyright header remains with it                  
or it is mentioned where you display your credits                      


Create a MySQL Database for the Calendar, if your not sure how contact your hosting provider

Upload the calendar folder to your server.

Make sure you have 'write' permissions on the folder before you begin installation.

Navigate to:

/calendar/install/install.php

Then follow the instructions

You will be able to login at:

/calendar/admin/admin_login.php

Login using "admin" as your login name AND password.
Once you have logged in you can and should change your login info.

IMPORTANT NOTES:
1 There is a setting to allow visitors to schedule events and should only be used in a trusted and/or secure environment.
   If someone is upset and this feature is enabled that person could start deleting your events!

2 For a smoother install; Appease the APP gods before installation and sacrifice one iPhone!
